This directory should be a subdirectory of your Eclipse {workspace} directory.
